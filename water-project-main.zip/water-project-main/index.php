<?php include "header.php"?>
<?php include "center.php"?>
<?php include "footer.php"?>