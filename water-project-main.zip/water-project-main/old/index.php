<?php include "header.php"?>
<?php include "content.php"?>
<?php include "footer.php"?>